/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sales.model;

import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 007
 */
public class FileOperations {

    public String headerFileName = "InvoiceHeader.csv";
    public String lineFileName = "InvoiceLine.csv";

    public FileOperations() {
        try {
            URL headerUrl = getClass().getResource(headerFileName);
            URL lineUrl = getClass().getResource(lineFileName);
            System.out.println(lineUrl.getPath());
            Path headerPath = Paths.get(headerUrl.getPath());
            Path linePath = Paths.get(lineUrl.getPath());

            ArrayList<InvoiceHeader> invoices = FileOperations.readFile(headerPath, linePath);
            for (InvoiceHeader invoice : invoices) {
                System.out.println(invoice);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static ArrayList<InvoiceHeader> readFile(Path headerPath, Path linePath) throws Exception {
        try {
            List<String> headerLines = Files.readAllLines(headerPath);
            ArrayList<InvoiceHeader> invoicesArray = new ArrayList<>();
            for (String headerLine : headerLines) {
                String[] headerParts = headerLine.split(",");
                int invoiceNum = Integer.parseInt(headerParts[0]);
                String invoiceDate = headerParts[1];
                String customerName = headerParts[2];

                InvoiceHeader invoice = new InvoiceHeader(invoiceNum, invoiceDate, customerName);
                invoicesArray.add(invoice);
            }
            List<String> lineLines = Files.readAllLines(linePath);
            System.out.println("Lines have been read");
            for (String lineLine : lineLines) {
                String lineParts[] = lineLine.split(",");
                int invoiceNum = Integer.parseInt(lineParts[0]);
                String itemName = lineParts[1];
                double itemPrice = Double.parseDouble(lineParts[2]);
                int count = Integer.parseInt(lineParts[3]);
                for (InvoiceHeader invoice : invoicesArray) {
                    if (invoice.getNum() == invoiceNum) {
                        LineModel line = new LineModel(itemName, itemPrice, count, invoice);
                        invoice.getLines().add(line);
                        break;
                    }
                }
            }
            return invoicesArray;
        } catch (Exception ex) {
            throw new Exception("can not read lines");
        }
    }

    public static void main(String[] args) {
        new FileOperations();
    }
//    public static void writeFile(ArrayList<InvoiceHeader> invoices) {
//        String headers = "";
//        String lines = "";
//        for (InvoiceHeader invoice : invoices) {
//            String invCSV = invoice.getAsCSV();
//            headers += invCSV;
//            headers += "\n";
//
//            for (LineModel line : invoice.getLines()) {
//                String lineCSV = line.getAsCSV();
//                lines += lineCSV;
//                lines += "\n";
//            }
//        }
//        System.out.println("Check point");
//        try {
//            JFileChooser fc = new JFileChooser();
//            int result = fc.showSaveDialog(frame);
//            if (result == JFileChooser.APPROVE_OPTION) {
//                File headerFile = fc.getSelectedFile();
//                FileWriter hfw = new FileWriter(headerFile);
//                hfw.write(headers);
//                hfw.flush();
//                hfw.close();
//                result = fc.showSaveDialog(frame);
//                if (result == JFileChooser.APPROVE_OPTION) {
//                    File lineFile = fc.getSelectedFile();
//                    FileWriter lfw = new FileWriter(lineFile);

//                    lfw.write(lines);
//                    lfw.flush();
//                    lfw.close();
//                }
//            }
//        } catch (Exception ex) {
//            JOptionPane.showMessageDialog(frame, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
//        }
//
//    }
}
